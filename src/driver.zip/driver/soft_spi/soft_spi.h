﻿#ifndef __SOFT_SPI_H__
#define __SOFT_SPI_H__
#include <SH88F4051.h>

sbit SCK = P1^1;
sbit MOSI = P1^2;
sbit MISO = P1^3;
sbit CSN = P1^4;

#define SETSCK() do { SCK = 1; } while(0)
#define CLRSCK() do { SCK = 0; } while(0)

#define SETMOSI() do { MOSI = 1; } while(0)
#define CLRMOSI() do { MOSI = 0; } while(0)

#define SETCSN() do { CSN = 1; } while(0)
#define CLRCSN() do { CSN = 0; } while(0)

uint8_t SPI_RW(uint8_t _byte);

#endif
