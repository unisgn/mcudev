﻿/*
 * @file		soft_spi.c
 * @author		
 * @date		
 * @version		v0.1
 * @desc		software spi simulation
 */
#include "soft_spi.h"

uint8_t SPI_RW(uint8_t _byte)
{
	uint8_t _bit;
	for(_bit = 0; _bit < 8; _bit++) {
		MOSI = _byte & 0x80;
		_byte <<= 1;
		SETSCK();
		_byte |= MISO;
		CLRSCK();
	}
	return _byte;
}
