
#ifndef __ST7920_REG_H__
#define __ST7920_REG_H__

/*
 * basic instruction set
 */
#define LCD_CLEAR				0x01
#define LCD_HOME				0x02
#define LCD_ENTRY_SETUP			0x04
#define LCD_DISP_STAT			0x08
#define LCD_CUR_DISP_CTRL		0x10
#define LCD_FN_SETUP			0x20
#define LCD_SET_CGRAM_ADDR		0x40
#define LCD_SET_DDRAM_ADDR		0x80

/*
 * extended instruction set
 */
#define LCD_STANDBY				LCD_CLEAR
#define LCD_VSCROLL				LCD_HOME
#define LCD_REVERSE				LCD_ENTRY_SETUP
#define LCD_SLEEP				LCD_DISP_STAT

#define LCD_SET_IRAM_ADDR		LCD_SET_CGRAM_ADDR
#define LCD_SET_GDRAM_ADDR		LCD_SET_DDRAM_ADDR


#endif
