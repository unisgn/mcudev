
#include "./st7920.h"
#include "./st7920_reg.h"



sbit RE;

void lcd_init(void)
{
	st7920_init_delay();
	RE = 0;
}

void lcd_clr_screen(void)
{
	st7920_wcmd(LCD_CLEAR);
}

void lcd_disp_str(uint8_t X, uint8_t Y, uint8_t* str, uint16_t length)
{

}

void lcd_disp_img(uint8_t X, uint8_t Y, uint8_t* img_code, uint16_t length)
{

}

void lcd_draw_point(uint8_t x, uint8_t y)
{
	
}

void lcd_draw_Hline(uint8_t y, uint8_t x1, uint8_t x2)
{

}

void lcd_draw_Vline(uint8_t x, uint8_t y1, uint8_t y2)
{

}

/*
 * delay for about 100ms;
 */
static void st7920_init_delay(void)
{
	uint16_t i = j = 10000;
	for(; i > 0; i--)
		for(; j > 0; j--);
}

/*
 * delay for about 100us;
 */
static void st7920_rw_delay(void)
{
	uint8_t i = j = 100;
	for(; i > 0; i--)
		for(; j > 0; j--);
}

static bool st7920_busy(void)
{
	bool ret = 0;
	SET_CMD_MODE();
	SET_READ();
	SET_EN();
	if(P0 & 0x80)
		ret = 1;
	return ret;
}

static void st7920_wcmd(uint8_t cmd)
{
	while(st7920_busy());
	SET_WRITE();
	SET_CMD_MODE();
	CLR_EN();
	LCD_DB = cmd;
	st7920_rw_delay();
	SET_EN();
}

static void st7920_wdat(uint8_t dat)
{
	while(st7920_busy());
	SET_WRITE();
	SET_DAT_MODE();
	CLR_EN();
	LCD_DB = dat;
	st7920_rw_delay();
	SET_EN();
}

static void st7920_enter_base_cmd_mode(void)
{
	if(RE) {
		st7920_wcmd(LCD_FN_SETUP + 0x21);
		RE = 0;
	}
}

static void st7920_enter_ext_cmd_mode(void)
{
	if(!RE) {
		st7920_wcmd(LCD_FN_SETUP + 0x01);
		RE = 1;
	}
}
