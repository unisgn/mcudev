
#ifndef __ST7920_H__
#define __ST7920_H__

#include <reg51.h>

#define LCD_DB P0;

sbit ST7920_RST = P1^1;

sbit ST7920_RS	= P1^2;
sbit ST7920_RW	= P1^3;
sbit ST7920_EN	= P1^4;

#define SET_EN			do { ST7920_EN  = 1; } while(0)
#define CLR_EN			do { ST7920_EN  = 0; } while(0)
#define SET_READ		do { ST7920_RW  = 1; } while(0)
#define SET_WRITE		do { ST7920_RW  = 0; } while(0)
#define SET_DAT_MODE	do { ST7920_RS  = 1; } while(0)
#define SET_CMD_MODE	do { ST7920_RS  = 0; } while(0)

typedef enum {
	ROW0,
	ROW1,
	ROW2,
	ROW3
} coor_row_t;

typedef enum {
	COL0,
	COL1,
	COL2,
	COL3,
	COL4,
	COL5,
	COL6,
	COL7
} coor_col_t;


void lcd_init(void);
void lcd_clr_screen(void);
void lcd_disp_str(uint8_t X, uint8_t Y, uint8_t* str, uint8_t length);
void lcd_disp_img(uint8_t X, uint8_t Y, uint8_t* img_code, uint8_t length);

#endif
