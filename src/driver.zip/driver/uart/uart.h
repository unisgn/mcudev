/*
 * @file
 * @author
 * @date
 * @version
 * @desc
 */

#ifndef __UART_H__
#define __UART_H__

#define UART_BaudRate 4800

void uart_init(void);
#endif
