﻿/*
 * @file
 * @author
 * @version
 * @desc
 *
 */

#ifndef __NRF24L01_H__
#define __NRF24L01_H__
#include <SH88F4051.H>
#include <types.h>

sbit CE = P1^5;
sbit IRQ = P1^6;

#define SETCE() do { CE = 1; } while(0)
#define CLRCE() do { CE = 0; } while(0)


/*
 * define data size, in byte;
 */
#define TX_ADDR_SIZE 3
#define RX_ADDR_SIZE 3
#define TX_PLOAD_SIZE 2
#define RX_PLOAD_SIZE 2


typedef enum {
	NRF_IDLE,
	NRF_TX_DS,
	NRF_MAX_RT,
	NRF_RX_DR,
	NRF_TX_AP,
	NRF_BUSY
} nrf_status_t;

uint8_t tx_addr[TX_ADDR_SIZE];
uint8_t tx_buf[TX_PLOAD_SIZE];

uint8_t rx_addr[RX_ADDR_SIZE];
uint8_t rx_buf[RX_PLOAD_SIZE];

void nrf24l01_init(void);
void nrf24l01_set_ptx_mode(void);

void nrf24l01_set_prx_mode(void);

//void nrf24l01_tx_pkt(void);
void nrf24l01_rx_pkt(void);

nrf_status_t nrf24l01_get_status(void);
void nrf24l01_reset_irq(void);
#endif
