﻿/*
 * @file:
 * @author:
 * @version:
 * @desc:
 */
#include "./nrf24l01.h"
#include "./nrf24l01_reg.h"
#include <soft_spi.h>

/*
 * @function
 * @desc: 
 */
void nrf24l01_init(void)
{
	nrf_spi_delay();
	CLRCE();
	SETCSN();
	CLRSCK();

	nrf_config();
}

/*
 * @function
 * @desc: setup tx_addr, tx_buf, before entering ptx mode;
 *		also setup rx_buf equal to tx_addr for ack;
 */

void nrf24l01_set_ptx_mode(void)
{
	CLRCE();

	nrf_write_buf(WRITE_REG + TX_ADDR, tx_addr, TX_ADDR_SIZE);
	nrf_write_buf(WRITE_REG + RX_ADDR_P0, rx_addr, RX_ADDR_SIZE);
	nrf_write_buf(WR_TX_PLOAD, tx_buf, TX_PLOAD_SIZE);

	nrf_write_reg(WRITE_REG + CONFIG, 0x0E);

	SETCE();
	nrf_spi_delay();
}


/*
 * @function
 * @desc: setup rx_buf before entering prx mode;
 */
void nrf24l01_set_prx_mode(void)
{
	CLRCE();

	nrf_write_buf(WRITE_REG + RX_ADDR_P0, rx_addr, RX_ADDR_SIZE);
	nrf_write_reg(WRITE_REG + CONFIG, 0x0F);

	SETCE();
	nrf_spi_delay();
}

/*
void nrf24l01_tx_pkt(void)
{

}
*/


void nrf24l01_rx_pkt(void)
{

}

void nrf24l01_reset_irq(void)
{
	nrf_write_reg(WRITE_REG + STATUS, 0x70);
}




static void nrf_spi_delay() 
{
	uint8_t i = 150;
	while(n--);
}

static void nrf_config()
{
	CLRCE();

	nrf_write_reg(WRITE_REG + EN_AA, 0x01);			// enable auto acknowledgement data pipe 0
	nrf_write_reg(WRITE_REG + EN_RXADDR, 0x01);		// enable data pipe 0
	nrf_write_reg(WRITE_REG + SETUP_AW, 0x01);		// setup 3 bytes address length
	nrf_write_reg(WRITE_REG + SETUP_RETR, 0x1A);	// setup auto retransmit delay 500us, retransmit count 10
	nrf_write_reg(WRITE_REG + RF_CH, 0x28);			// setup RF channel to 2440MHz
	nrf_write_reg(WRITE_REG + RF_SETUP, 0x06);		// setup RF output power=0dBm, data rate=1Mbps
	// TX_ADDR, RX_ADDR, PAYLOAD will be configed on demand;
	
	SETCE();
	nrf_spi_delay();
}

/*
 * read register value through soft spi
 */
static uint8_t nrf_read_reg(uint8_t reg)
{
	uint8_t reg_value;
	CLRCSN();
	SPI_RW(reg);
	reg_value = SPI_RW(0);
	SETCSN();
	return reg_value;
}

/*
 * write a byte of data to register through soft spi
 */
static void nrf_write_reg(uint8_t reg, uint8_t dat)
{
	uint8_t retval;
	CLRCSN();
	SPI_RW(reg);
	SPI_RW(dat);
	SETCSN();
}

/*
 * read buffer from specified register
 */
static void nrf_read_buf(uint8_t reg, uint8_t *bufPtr, uint8_t bufSize)
{
	uint8_t ptr = bufSize;
	CLRCSN();
	SPI_RW(reg);
	while(ptr--) {
		*bufPtr++ = SPI_RW(0);
	}
	SETCSN();
}

/*
 * write a buffer to specified register
 */
static void nrf_write_buf(uint8_t reg, uint8_t *bufPtr, uint8_t bufSize)
{
	uint8_t ptr = bufSize;
	CLRCSN();
	SPI_RW(reg);
	while(ptr--) {
		SPI_RW(*bufPtr++);
	}
	SETCSN();
}
